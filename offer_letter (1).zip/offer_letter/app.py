# ✅ Cell 1: Install required libraries (run only once)
# ✅ Remove the !pip line completely
import gradio as gr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib
import re
import requests
from bs4 import BeautifulSoup
import fitz  # PyMuPDF for PDF reading


# ✅ Cell 2: Imports and Model Setup
import gradio as gr
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import joblib
import re
import requests
from bs4 import BeautifulSoup
import fitz  # PyMuPDF for PDF reading

# Sample training data
data = [
    ("Congratulations! You've been selected. Pay ₹5000 for processing.", "fake"),
    ("We are happy to offer you an internship at Infosys with monthly stipend ₹10,000.", "legit"),
    ("You have won a paid internship at Google! Please share Aadhaar to proceed.", "fake"),
    ("Your profile has been shortlisted for a role at Microsoft. No fee is required.", "legit"),
    ("Pay registration amount of ₹2000 to receive offer letter.", "fake"),
    ("We are pleased to offer you an internship at TCS for the role of Software Intern.", "legit"),
]

# Train model
texts = [x[0] for x in data]
labels = [x[1] for x in data]
model = make_pipeline(TfidfVectorizer(), MultinomialNB())
model.fit(texts, labels)
joblib.dump(model, "job_offer_legit_model.pkl")

# ✅ Extract company name
def extract_company_name(text):
    company_keywords = ["at", "from", "with"]
    for word in company_keywords:
        match = re.search(rf"{word} ([A-Z][a-zA-Z0-9&]+)", text)
        if match:
            return match.group(1)
    return "Unknown"

# ✅ Extract website URL
def extract_website_url(text):
    match = re.search(r"https?://[^\s]+", text)
    if match:
        return match.group(0)
    return None

# ✅ Check if website active
def check_website_active(url):
    if not url:
        return False
    try:
        response = requests.get(url, timeout=5)
        return response.status_code == 200
    except:
        return False

# ✅ Read text from PDF file
def extract_text_from_pdf(pdf_file):
    text = ""
    with fitz.open(pdf_file.name) as doc:
        for page in doc:
            text += page.get_text()
    return text.strip()

# ✅ Enhanced logic to classify and analyze
def enhanced_check_offer_legitimacy(text):
    model = joblib.load("job_offer_legit_model.pkl")
    pred = model.predict([text])[0]
    prob = model.predict_proba([text])[0]
    confidence = round(max(prob) * 100, 2)

    company = extract_company_name(text)
    url = extract_website_url(text)
    website_status = check_website_active(url)

    result = f"Prediction: {pred.upper()} OFFER\nConfidence: {confidence}%"
    result += f"\nCompany Name: {company}"
    if url:
        result += f"\nWebsite: {url} (Active: {'Yes' if website_status else 'No'})"
    return result

# ✅ Markdown-styled beautified output with visible effects
def beautified_output(input_text, pdf_file):
    if pdf_file is not None:
        input_text = extract_text_from_pdf(pdf_file)
    
    if not input_text.strip():
        return "⚠️ Please enter text or upload a PDF."

    result = enhanced_check_offer_legitimacy(input_text)
    lines = result.split("\n")
    md = ""
    offer_type = ""
    
    # Determine if offer is legit or fake
    for line in lines:
        if "Prediction" in line:
            if "LEGIT" in line:
                offer_type = "legit"
            else:
                offer_type = "fake"
    
    for line in lines:
        if "FAKE" in line:
            md += f'<span style="color:red; font-weight:bold; animation: blink 1s infinite;">❌ {line}</span><br>'
        elif "LEGIT" in line:
            md += f'<span style="color:lime; font-weight:bold; animation: bounce 1s infinite;">✅ {line}</span><br>'
        elif "Confidence" in line:
            # Change color based on LEGIT/FAKE
            if offer_type == "legit":
                color = "deepskyblue"  # Blue for legit
            else:
                color = "orange"       # Orange for fake
            md += f'<span style="color:{color}; font-weight:bold; text-shadow: 0 0 10px {color}, 0 0 20px {color};">🔍 {line}</span><br>'
        elif "Company" in line:
            md += f'🏢 {line}<br>'
        elif "Website" in line:
            md += f'🔗 {line}<br>'
        else:
            md += f'{line}<br>'
    return md


# ✅ Example Offers
example_offers = [
    "Congratulations! You've been selected. Pay ₹5000 for processing.",
    "We are pleased to offer you an internship at TCS for the role of Software Intern.",
    "You have won a paid internship at Google! Please share Aadhaar to proceed.",
    "Your profile has been shortlisted for a role at Microsoft. No fee is required.",
    "Apply for internship at XYZ Pvt Ltd. Visit our LinkedIn: https://www.linkedin.com/company/xyz"
]

# ✅ Gradio Interface with PDF input + CSS effects
custom_css = """
@keyframes blink {
  0% {opacity:1;}
  50% {opacity:0.5;}
  100% {opacity:1;}
}
@keyframes bounce {
  0%,100% {transform: translateY(0);}
  50% {transform: translateY(-5px);}
}
.gr-input textarea {
  border-radius: 12px;
  padding: 10px;
  border: 2px solid #00c6ff;
  transition: all 0.3s ease;
}
.gr-input textarea:hover {
  border: 2px solid #ff6a00;
  box-shadow: 0 0 10px #ff6a00;
}
.gr-button {
  background: linear-gradient(to right, #0072ff, #00c6ff);
  color: white;
  font-weight: bold;
  border-radius: 12px;
  padding: 10px 20px;
  border: none;
  transition: all 0.3s ease;
}
.gr-button:hover {
  transform: scale(1.05);
  background-color: #00ff99 !important;
}
.gr-file input[type="file"]:hover {
  cursor: pointer;
  transform: scale(1.05);
}
.gr-markdown {
  background: rgba(0,0,0,0.3);
  border-radius: 15px;
  padding: 15px;
}
"""

app = gr.Interface(
    fn=beautified_output,
    inputs=[
        gr.Textbox(lines=8, label="📋 Paste Job/Internship Offer Letter"),
        gr.File(label="📎 Or Upload Offer Letter (PDF)", file_types=[".pdf"])
    ],
    outputs=gr.Markdown(label="📄 Analysis Result"),
    examples=[[ex, None] for ex in example_offers],
    title="🛡️ AI-Powered Internship/Job Offer Legitimacy Checker",
    description="""
    🔍 Paste your job or internship offer text **or upload a PDF**.  
    This AI tool detects scam indicators using machine learning and company info validation.
    """,
    theme="gradio/soft",
    css=custom_css
)

# ✅ Launch App
app.launch(share=True)
